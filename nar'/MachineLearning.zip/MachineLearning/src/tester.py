#!/usr/bin/env python

print("test")